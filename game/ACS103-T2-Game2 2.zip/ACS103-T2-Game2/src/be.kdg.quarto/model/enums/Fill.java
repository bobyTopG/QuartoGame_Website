package be.kdg.quarto.model.enums;

public enum Fill {
    FULL, HOLLOW;
}
