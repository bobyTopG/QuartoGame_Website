package be.kdg.quarto.model.enums;

public enum Color {
    WHITE, BLACK;
}
