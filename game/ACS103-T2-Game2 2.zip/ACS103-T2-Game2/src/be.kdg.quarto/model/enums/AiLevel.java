package be.kdg.quarto.model.enums;

public enum AiLevel {
    EASY, MEDIUM, HARD
}
