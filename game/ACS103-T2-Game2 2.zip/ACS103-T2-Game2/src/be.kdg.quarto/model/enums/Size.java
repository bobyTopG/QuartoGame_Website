package be.kdg.quarto.model.enums;

public enum Size {
    BIG, SMALL;
}

