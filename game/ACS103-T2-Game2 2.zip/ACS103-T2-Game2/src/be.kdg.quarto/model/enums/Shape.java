package be.kdg.quarto.model.enums;

public enum Shape {
    CIRCLE, SQUARE;
}
