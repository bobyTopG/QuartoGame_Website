package be.kdg.quarto.view.ChooseAIScreen;

import be.kdg.quarto.helpers.Auth.AuthHelper;
import be.kdg.quarto.helpers.CreateHelper;
import be.kdg.quarto.helpers.ErrorHelper;
import be.kdg.quarto.helpers.ImageHelper;
import be.kdg.quarto.model.GameSession;
import be.kdg.quarto.model.Player;
import be.kdg.quarto.view.GameScreen.GamePresenter;
import be.kdg.quarto.view.GameScreen.GameView;
import be.kdg.quarto.view.StartScreen.StartPresenter;
import be.kdg.quarto.view.StartScreen.StartView;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import be.kdg.quarto.helpers.Characters;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static be.kdg.quarto.helpers.ImageHelper.getOpponentImage;

public class ChooseAIPresenter {
    private final ChooseAIView view;
    private Player opponentSelected;
    private final boolean isOnline;

    public ChooseAIPresenter(ChooseAIView view, boolean online) {
        this.view = view;
        List<Image> images = null;
        try {
            images = findAICharacterImagesForButtons();
        } catch (Exception e) {
            ErrorHelper.showError(e,"One or more AI character images could not found");
        }
        String pathToNotFound = "/images/aiCharacters/100px/BoxedNotFound.png";
        Image notFoundImage = new Image(pathToNotFound);
        view.initialise(images, Characters.getCharacters(), notFoundImage);
        this.isOnline = online;

        updateView();
        addEventHandlers();
    }

    private List<Image> findAICharacterImagesForButtons() throws Exception {
        List<Player> AiList = Characters.getCharacters();
        List<Image> images = new ArrayList<>();
        for (Player ai : AiList) {
            String imagePath = "/images/aiCharacters/100px/Boxed" + ai.getName() + ".png";
            Image image;
            try {
                image = new Image(Objects.requireNonNull(getClass().getResource(imagePath)).toString());
            }catch (Exception e) {
                throw new Exception("Ai Character Image not Found");
            }
            images.add(image);
        }
        return images;
    }

    private void addEventHandlers() {

        int count = 0;

        for (Button characterButton : view.getCharacterButtons()) {
            final int id = count;
            characterButton.setOnMouseClicked(event -> {
                view.setSelectedCharacter(id);
                view.getSelectButton().setDisable(false);
                opponentSelected = Characters.getCharacter(id);
            });
            count++;
        }


        for (Button notFoundButton : view.getNotFoundButtons()) {
            notFoundButton.setOnMouseClicked(event -> {
                view.setSelectedCharacter(-1);
                view.getSelectButton().setDisable(true);
                opponentSelected = null;
            });
        }


        view.getBackButton().setOnMouseClicked(event -> {
            StartView startView = new StartView();
            view.getScene().setRoot(startView);
            new StartPresenter(startView);
        });


        view.getSelectButton().setOnMouseClicked(event -> {
            if (opponentSelected != null) {
                GameView gameView = new GameView(ImageHelper.getPlayerImage(), getOpponentImage(opponentSelected), opponentSelected.getName());
                GameSession model;
                //if offline play as guest
                try {
                    model = new GameSession(
                            (AuthHelper.isLoggedIn() && isOnline) ? AuthHelper.getLoggedInPlayer() : AuthHelper.getGuestPlayer(),
                            opponentSelected, view.getTurnButton().isSelected()? null : opponentSelected, isOnline
                    );
                    view.getScene().setRoot(gameView);
                    new GamePresenter(model, gameView);
                } catch (SQLException e) {
                    CreateHelper.showAlert("Database Error", e.getMessage(),true);
                }


            }
        });

        // Hover effect on focus for character buttons
        for (Button characterButton : view.getCharacterButtons()) {
            characterButton.focusedProperty().addListener((obs, oldVal, isFocused) -> {
                characterButton.pseudoClassStateChanged(javafx.css.PseudoClass.getPseudoClass("hover"), isFocused);
            });
        }

        // Hover effect on focus for notFound buttons
        for (Button notFoundButton : view.getNotFoundButtons()) {
            notFoundButton.focusedProperty().addListener((obs, oldVal, isFocused) -> {
                notFoundButton.pseudoClassStateChanged(javafx.css.PseudoClass.getPseudoClass("hover"), isFocused);
            });
        }

        // Hover effect on select and back buttons
        view.getSelectButton().focusedProperty().addListener((obs, oldVal, isFocused) -> {
            view.getSelectButton().pseudoClassStateChanged(javafx.css.PseudoClass.getPseudoClass("hover"), isFocused);
        });
        view.getBackButton().focusedProperty().addListener((obs, oldVal, isFocused) -> {
            view.getBackButton().pseudoClassStateChanged(javafx.css.PseudoClass.getPseudoClass("hover"), isFocused);
        });

        view.getScene().setOnKeyPressed(event -> {
            switch (event.getCode()) {
                case ENTER, SPACE -> {
                    // If a character button is focused, simulate its selection
                    for (int i = 0; i < view.getCharacterButtons().size(); i++) {
                        if (view.getCharacterButtons().get(i).isFocused()) {
                            view.setSelectedCharacter(i);
                            view.getSelectButton().setDisable(false);
                            opponentSelected = Characters.getCharacter(i);
                            return;
                        }
                    }
                    for (Button notFoundButton : view.getNotFoundButtons()) {
                        if (notFoundButton.isFocused()) {
                            view.setSelectedCharacter(-1);
                            view.getSelectButton().setDisable(true);
                            opponentSelected = null;
                            return;
                        }
                    }
                    if (view.getBackButton().isFocused()) {
                        StartView startView = new StartView();
                        view.getScene().setRoot(startView);
                        new StartPresenter(startView);
                    } else if (view.getSelectButton().isFocused() && opponentSelected != null) {
                        GameView gameView = new GameView(ImageHelper.getPlayerImage(), getOpponentImage(opponentSelected), opponentSelected.getName());
                        try {
                            GameSession model = new GameSession(
                                    (AuthHelper.isLoggedIn() && isOnline) ? AuthHelper.getLoggedInPlayer() : AuthHelper.getGuestPlayer(),
                                    opponentSelected,
                                    view.getTurnButton().isSelected() ? null : opponentSelected,
                                    isOnline
                            );
                            view.getScene().setRoot(gameView);
                            new GamePresenter(model, gameView);
                        } catch (SQLException e) {
                            CreateHelper.showAlert("Database Error", e.getMessage(), true);
                        }
                    }
                }
            }
        });
    }

    private void updateView() {
        view.getScene().getRoot().setStyle("-fx-background-color: #fff4d5;");
    }

}