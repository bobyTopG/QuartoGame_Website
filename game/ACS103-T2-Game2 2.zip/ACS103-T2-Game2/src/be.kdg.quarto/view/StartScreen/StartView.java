package be.kdg.quarto.view.StartScreen;

import be.kdg.quarto.helpers.Auth.AuthHelper;
import be.kdg.quarto.helpers.CreateHelper;
import be.kdg.quarto.helpers.ImageHelper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;


public class StartView extends StackPane {

    private Label label;
    private Button register, login, leaderboard, quit, play;
    private HBox mainHBox;

    private VBox leftVBox;
    private BorderPane root;

    private Button online;
    private final Label onlineText = CreateHelper.createLabel("","online-text");
    private final Label userText = CreateHelper.createLabel("","user-text");

    public StartView() {
        initialiseNodes();
        layoutNodes();
        setupFocusHoverEffects();
    }
    //private static final String FONT_FILE = "/fonts/berlin.ttf"; // Relative path

    private void initialiseNodes() {
        label = CreateHelper.createLabel("Quarto!", "main-title");
        root = new BorderPane();

        register = CreateHelper.createButton(AuthHelper.isLoggedIn() ? "New Game" : "Register",  new String[]{"green-button", "default-button"});
        login = CreateHelper.createButton(AuthHelper.isLoggedIn() ? "Continue" : "Login", new String[]{"orange-button", "default-button"});
        leaderboard = CreateHelper.createButton("Leaderboard", new String[]{"blue-button", "default-button"});
        quit = CreateHelper.createButton("Quit", new String[]{"red-button", "default-button"});
        mainHBox = CreateHelper.createHBox("root-hbox");
        play = CreateHelper.createButton("Play", new String[]{"green-button", "default-button","big-button"});
        leftVBox = CreateHelper.createVBox("start-main-vbox");

    }


    private void layoutNodes() {


        mainHBox.getChildren().add(leftVBox);
        //set the menu to Offline until not found connection
        switchOnlineMode(false);

        root.setCenter(mainHBox);
        VBox onlineVBox =  createOnlineButton();
        this.getChildren().addAll(root,onlineVBox);
        this.setAlignment(Pos.TOP_RIGHT);
    }

    public void loadBoardImage(Image boardImage) {
        StackPane board = new StackPane();
        ImageView boardImageView = new ImageView(boardImage); // No cast needed
        boardImageView.setFitHeight(400);
        boardImageView.setFitWidth(400);
        board.getChildren().add(boardImageView);
        mainHBox.getChildren().add(board);
    }
    void setOnlineButtonToConnecting(){
        onlineImageView.setImage(new Image(ImageHelper.getLoadingButtonPath()));
        online.setGraphic(onlineImageView);

    }

    void switchOnlineMode(boolean online) {
        if (online) {
            leftVBox.getChildren().clear();  // Clear first to prevent duplicates
            leftVBox.getChildren().addAll(label, register, login, leaderboard, quit);
            userText.setText(AuthHelper.isLoggedIn() ? "Logged in as:\n" + AuthHelper.getLoggedInPlayer().getName() : "Not logged in");
        } else {
            leftVBox.getChildren().clear();  // Clear first to prevent duplicates
            leftVBox.getChildren().addAll(label, play, quit);
            userText.setText("");
        }
    }
    ImageView onlineImageView;
    VBox createOnlineButton() {
        VBox onlineBox = new VBox();
        onlineBox.setAlignment(Pos.TOP_RIGHT);

        online = new Button();
        onlineImageView = new ImageView(new Image(ImageHelper.getLoadingButtonPath()));

        // Set the image size
        onlineImageView.setFitWidth(40);
        onlineImageView.setFitHeight(40);

        onlineImageView.setPreserveRatio(true);

        // Set the image on the button
        online.setGraphic(onlineImageView);
        onlineBox.setPadding(new Insets(10));
        onlineBox.setMaxWidth(150);      // Adjust to your desired size

        // Remove default button styling
        online.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");


        onlineBox.getChildren().addAll(online, onlineText, userText);
        return onlineBox;
    }


    // Getters

     Button getRegister() {
        return register;
    }

     Button getLogin() {
        return login;
    }

     Button getLeaderboard() {
        return leaderboard;
    }

     Button getQuit() {
        return quit;
    }

    Button getOnline(){
        return online;
    }

    Button getPlay() {
        return play;
    }
    Label getOnlineText() {
        return onlineText;
    }
    Label getUserText() {
        return userText;
    }
    // --- Button Focus Navigation Support ---
    public void focusNext() {
        Button[] buttons = getCurrentButtons();
        for (int i = 0; i < buttons.length; i++) {
            if (buttons[i].isFocused()) {
                buttons[(i + 1) % buttons.length].requestFocus();
                return;
            }
        }
        buttons[0].requestFocus(); // Fallback if none are focused
    }

    public void focusPrevious() {
        Button[] buttons = getCurrentButtons();
        for (int i = 0; i < buttons.length; i++) {
            if (buttons[i].isFocused()) {
                buttons[(i - 1 + buttons.length) % buttons.length].requestFocus();
                return;
            }
        }
        buttons[buttons.length - 1].requestFocus(); // Fallback if none are focused
    }

    private Button[] getCurrentButtons() {
        if (AuthHelper.isLoggedIn()) {
            return new Button[]{register, login, leaderboard, quit};
        } else {
            return new Button[]{play, quit};
        }
    }

    private void setupFocusHoverEffects() {
        for (Button button : getCurrentButtons()) {
            button.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
                button.pseudoClassStateChanged(javafx.css.PseudoClass.getPseudoClass("hover"), isNowFocused);
            });
        }
    }
}