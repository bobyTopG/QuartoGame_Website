open module ACS103.T2.Game {
    requires javafx.graphics;
    requires javafx.controls;
    requires java.desktop;
    requires java.sql;
}